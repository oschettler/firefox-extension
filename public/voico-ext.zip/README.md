# VoiCo Firefox Extension

Show a Voice Code on every website.
